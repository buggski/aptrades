import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import backtest  # noqa: E402
import strategies as s  # noqa: E402


def make_day(closes, spread=0.2):
    idx = pd.date_range("2026-11-02 09:30", periods=len(closes), freq="5min", tz="America/New_York")
    c = np.array(closes, dtype=float)
    o = np.r_[c[0], c[:-1]]
    return pd.DataFrame({"open": o, "high": np.maximum(o, c) + spread,
                         "low": np.minimum(o, c) - spread, "close": c, "volume": 1000}, index=idx)


def test_orb_fires_on_first_breakout():
    day = make_day([100, 100.5, 100.2, 100.4, 101.5])
    sig = s.orb_signal(day, 3, 2.0)
    assert sig and sig["entry"] == 101.5
    assert sig["stop"] < 100 and sig["target"] > sig["entry"]


def test_orb_no_chasing_old_breakout():
    day = make_day([100, 100.5, 100.2, 101.5, 101.8])
    assert s.orb_signal(day, 3, 2.0) is None


def test_orb_no_signal_inside_range():
    assert s.orb_signal(make_day([100, 100.5, 100.2, 100.3, 100.1]), 3) is None


def test_ema_long_in_uptrend_flat_in_downtrend():
    up = pd.Series(np.linspace(100, 200, 400))
    down = pd.Series(np.linspace(200, 100, 400))
    assert s.ema_signal(up) == "long"
    assert s.ema_signal(down) == "flat"
    assert s.ema_signal(up.iloc[:50]) == "flat"  # not enough history


def test_prob_up_sane():
    assert abs(s.prob_up(100, 100, 0.001, 5) - 0.5) < 1e-9
    assert s.prob_up(101, 100, 0.001, 5) > 0.95
    assert s.prob_up(99, 100, 0.001, 5) < 0.05
    assert s.prob_up(100, 100.01, 0.001, 0) == 0.0


def test_fee_and_decision():
    assert s.kalshi_fee(0.5) == 0.02  # 0.07*0.25 = 0.0175 -> rounds up to 2 cents
    assert s.kalshi_decision(0.80, 0.60, 0.42) == ("yes", 0.60, 0.80 - 0.60 - s.kalshi_fee(0.60))
    side, _, _ = s.kalshi_decision(0.20, 0.82, 0.20)
    assert side == "no"
    assert s.kalshi_decision(0.55, 0.53, 0.49) is None  # edge too small after fee


def test_backtest_sims_run():
    day = make_day([100, 100.5, 100.2, 100.4, 101.5, 102, 103, 104, 105, 104])
    assert len(backtest.simulate_orb_day(day)) == 1
    closes = pd.Series(np.r_[np.linspace(100, 150, 300), np.linspace(150, 120, 100)])
    trades = backtest.simulate_ema(closes)
    assert len(trades) >= 1
